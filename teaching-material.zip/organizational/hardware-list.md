## External hardware
- micro:bit (4)
- bit:bot (2)
- circuit plug board; no soldering (2)
- small speaker (2)
- LEDs, appropriate resistors, wires


## This should be available on-site
- computers with USB plug (at least one per two students; preferably one each)
    - operating system doesn't matter as long as it supports a modern browser
- Wi-Fi connection (minimally a local network - important to know beforehand)
